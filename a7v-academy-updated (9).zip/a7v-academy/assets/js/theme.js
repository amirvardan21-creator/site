/* A7V Academy — interactions only (content rendered server-side by PHP) */
document.addEventListener('DOMContentLoaded', function () {
  // Sticky header
  var header = document.getElementById('siteHeader');
  if (header) {
    window.addEventListener('scroll', function () {
      header.classList.toggle('scrolled', window.scrollY > 20);
    });
  }
  // Mobile drawer
  var ham = document.getElementById('hamburger'),
      drawer = document.getElementById('mobileDrawer'),
      ov = document.getElementById('overlay');
  function closeDrawer() { if (drawer) drawer.classList.remove('open'); if (ov) ov.classList.remove('show'); }
  if (ham) ham.addEventListener('click', function () { drawer.classList.add('open'); ov.classList.add('show'); });
  if (ov) ov.addEventListener('click', closeDrawer);
  if (drawer) drawer.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', closeDrawer); });
  // Notice bar
  var nc = document.getElementById('noticeClose');
  if (nc) nc.addEventListener('click', function () {
    var bar = document.getElementById('noticeBar'); if (bar) bar.classList.add('hide');
  });
  // Countdown
  var cd = document.getElementById('countdown');
  if (cd) {
    var total = 48 * 3600;
    setInterval(function () {
      total = total > 0 ? total - 1 : 48 * 3600;
      var h = String(Math.floor(total / 3600)).padStart(2, '0');
      var m = String(Math.floor((total % 3600) / 60)).padStart(2, '0');
      var s = String(total % 60).padStart(2, '0');
      cd.textContent = h + ':' + m + ':' + s;
    }, 1000);
  }
  // FAQ accordion
  document.querySelectorAll('.faq-q').forEach(function (q) {
    q.addEventListener('click', function () { q.parentElement.classList.toggle('open'); });
  });
  // Row sliders (RTL aware)
  document.querySelectorAll('.row-nav').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var track = document.getElementById('track-' + btn.dataset.row);
      if (!track) return;
      var dir = btn.classList.contains('next') ? 1 : -1;
      track.scrollBy({ left: dir * -300, behavior: 'smooth' });
    });
  });

  // Auth tabs (register / login)
  document.querySelectorAll('[data-auth-tab]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = b.dataset.authTab;
      document.querySelectorAll('[data-auth-tab]').forEach(function (x) { x.classList.toggle('active', x === b); });
      document.querySelectorAll('.auth-form').forEach(function (f) { f.classList.toggle('active', f.dataset.form === t); });
    });
  });

  // Dashboard tabs
  document.querySelectorAll('.dash-menu [data-tab]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = b.dataset.tab;
      document.querySelectorAll('.dash-menu [data-tab]').forEach(function (x) { x.classList.toggle('active', x === b); });
      document.querySelectorAll('.dash-panel').forEach(function (p) { p.classList.toggle('active', p.dataset.panel === t); });
      var main = document.querySelector('.dash-main');
      if (main) main.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
});


/* Paywall popup (download / locked content) */
document.addEventListener('DOMContentLoaded', function () {
  var modal = document.getElementById('a7vPaywall');
  function openModal() { if (modal) { modal.classList.add('open'); document.body.style.overflow = 'hidden'; } }
  function closeModal() { if (modal) { modal.classList.remove('open'); document.body.style.overflow = ''; } }
  document.querySelectorAll('.js-locked').forEach(function (el) {
    el.addEventListener('click', function (e) { e.preventDefault(); openModal(); });
  });
  if (modal) {
    modal.querySelectorAll('[data-close]').forEach(function (c) { c.addEventListener('click', closeModal); });
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
});

/* ============================================================
   A7V Hero Stats Animated Counters (Elementor style easeOut)
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
  var cards = document.querySelectorAll('.a7v-stat-card');
  if (!cards.length) return;

  function formatThousand(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  function runCounter(card) {
    var numEl = card.querySelector('.a7v-stat-num');
    if (!numEl) return;
    var target = parseInt(card.dataset.num, 10) || 0;
    var suffix = card.dataset.suffix || '';
    var duration = parseInt(card.dataset.duration, 10) || 2200;
    var startTime = null;

    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      var elapsed = timestamp - startTime;
      var progress = Math.min(elapsed / duration, 1);
      // Elementor-style Quartic Ease-Out curve for luxury smooth deceleration
      var easeOutQuart = 1 - Math.pow(1 - progress, 4);
      var current = Math.floor(easeOutQuart * target);
      numEl.textContent = formatThousand(current) + suffix;
      if (progress < 1) {
        window.requestAnimationFrame(step);
      } else {
        numEl.textContent = formatThousand(target) + suffix;
      }
    }
    window.requestAnimationFrame(step);
  }

  // In preview iframes (Home Builder or Customizer) or if IntersectionObserver fails, run immediately!
  var isPreviewFrame = (window.frameElement || window.parent !== window || window.location.search.indexOf('a7v_preview') !== -1 || window.location.search.indexOf('customize_changeset_uuid') !== -1);
  if (isPreviewFrame || !('IntersectionObserver' in window)) {
    cards.forEach(runCounter);
  } else {
    var obs = new IntersectionObserver(function (entries, observer) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting || entry.intersectionRatio > 0) {
          runCounter(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.01 });
    cards.forEach(function (c) { obs.observe(c); });
    // Safety fallback: if not triggered after 1.5 seconds, start anyway so numbers are never stuck at 0
    setTimeout(function() { cards.forEach(runCounter); }, 1500);
  }
});

/* ============================================================
   A7V Dark Mysterious Ambient Music Player (Header Audio Toggle)
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
  var btn = document.getElementById('a7vAudioBtn');
  if (!btn) return;

  var isPlaying = false;
  var audioEl = null;
  var audioCtx = null;
  var osc1 = null, osc2 = null, osc3 = null, lfo = null, gainNode = null;

  function stopSynth() {
    if (osc1) { try { osc1.stop(); } catch(e){} osc1 = null; }
    if (osc2) { try { osc2.stop(); } catch(e){} osc2 = null; }
    if (osc3) { try { osc3.stop(); } catch(e){} osc3 = null; }
    if (lfo)  { try { lfo.stop(); } catch(e){} lfo = null; }
    if (audioCtx && audioCtx.state !== 'closed') {
      try { audioCtx.suspend(); } catch(e){}
    }
  }

  function startSynth() {
    var AudioCtxClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtxClass) return;
    if (!audioCtx) {
      audioCtx = new AudioCtxClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    // Deep cinematic A-minor power drone
    osc1 = audioCtx.createOscillator();
    osc2 = audioCtx.createOscillator();
    osc3 = audioCtx.createOscillator();
    lfo  = audioCtx.createOscillator();

    var filter = audioCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 160;

    var lfoGain = audioCtx.createGain();
    lfoGain.gain.value = 45;
    lfo.frequency.value = 0.12; // slow breathing modulation
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);

    osc1.type = 'sine';
    osc1.frequency.value = 55.0; // A1 deep bass
    osc2.type = 'triangle';
    osc2.frequency.value = 82.41; // E2 minor fifth
    osc3.type = 'sine';
    osc3.frequency.value = 110.0; // A2 octave warmth

    gainNode = audioCtx.createGain();
    gainNode.gain.value = 0.16; // luxury subtle ambient drone

    osc1.connect(filter);
    osc2.connect(filter);
    osc3.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    var now = audioCtx.currentTime;
    osc1.start(now);
    osc2.start(now);
    osc3.start(now);
    lfo.start(now);
  }

  btn.addEventListener('click', function () {
    var url = btn.dataset.audio || '';
    if (isPlaying) {
      isPlaying = false;
      btn.classList.remove('playing');
      if (audioEl) {
        audioEl.pause();
      } else {
        stopSynth();
      }
    } else {
      isPlaying = true;
      btn.classList.add('playing');
      if (url) {
        if (!audioEl) {
          audioEl = new Audio(url);
          audioEl.loop = true;
        }
        audioEl.play().catch(function () {
          isPlaying = false;
          btn.classList.remove('playing');
        });
      } else {
        startSynth();
      }
    }
  });
});
