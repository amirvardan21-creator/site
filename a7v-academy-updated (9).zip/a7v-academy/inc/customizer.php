<?php
/**
 * Theme Customizer — colors, hero, sections toggle.
 *
 * @package A7V
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

function a7v_customize_register( $wp_customize ) {

        /* ---------- Panel ---------- */
        $wp_customize->add_panel( 'a7v_panel', array(
                'title'    => 'تنظیمات A7V',
                'priority' => 1,
        ) );

        /* ---------- Colors ---------- */
        $wp_customize->add_section( 'a7v_colors', array(
                'title' => 'رنگ‌ها',
                'panel' => 'a7v_panel',
        ) );

        $colors = array(
                'a7v_brand' => array( 'قرمز برند', '#e01e2b' ),
                'a7v_glow'  => array( 'قرمز درخشش (Glow)', '#ff3b3b' ),
                'a7v_gold'  => array( 'طلایی VIP', '#c9a24b' ),
                'a7v_bg'    => array( 'پس‌زمینه عمیق', '#070708' ),
        );
        foreach ( $colors as $id => $c ) {
                $wp_customize->add_setting( $id, array(
                        'default'           => $c[1],
                        'sanitize_callback' => 'sanitize_hex_color',
                        'transport'         => 'refresh',
                ) );
                $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, array(
                        'label'   => $c[0],
                        'section' => 'a7v_colors',
                ) ) );
        }

        /* ---------- Hero ---------- */
        $wp_customize->add_section( 'a7v_hero', array(
                'title'    => '۱. هدر سایت و بخش قهرمان (Hero)',
                'panel'    => 'a7v_panel',
                'priority' => 10,
        ) );
        /* ---------- Hero Stats Section ---------- */
        $wp_customize->add_section( 'a7v_hero_stats_sec', array(
                'title'    => '۲. کارت‌های ۴ گانه آمار هدر / هیرو (Stats)',
                'panel'    => 'a7v_panel',
                'priority' => 11,
        ) );
        /* ---------- Live Music Section ---------- */
        $wp_customize->add_section( 'a7v_live_music_sec', array(
                'title'    => '۳. موزیک زنده پس‌زمینه (Live Music)',
                'panel'    => 'a7v_panel',
                'priority' => 12,
        ) );
        /* ---------- Confidential Dossier Categories Section ---------- */
        $wp_customize->add_section( 'a7v_cats_sec', array(
                'title'    => '۴. کارت‌های دسته‌بندی محرمانه (Categories)',
                'panel'    => 'a7v_panel',
                'priority' => 13,
        ) );

        $hero_fields = array(
                'a7v_hero_title'    => array( 'عنوان اصلی (آکادمی)', 'آکادمی', 'text' ),
                'a7v_hero_accent'   => array( 'عنوان برجسته قرمز (مافیا)', 'مافیا', 'text' ),
                'a7v_hero_tagline'  => array( 'متن زیر عنوان (شعار)', 'نسخه قدرتمندتر خودت را بساز.', 'text' ),
                'a7v_hero_desc'     => array( 'توضیح هیرو', 'به آکادمی مافیا خوش آمدید. جایی که یادگیری تبدیل به قدرت می‌شود. از دوره‌های آموزشی حرفه‌ای تا مقالات استراتژیک و ابزارهای مدرن برای ساختن نسخه‌ی قدرتمندتر از خودت.', 'textarea' ),
                'a7v_hero_cta'      => array( 'متن دکمه اول (قرمز و اصلی)', 'ورود به حلقه قدرت', 'text' ),
                'a7v_hero_cta_url'  => array( 'لینک دکمه اول', '#', 'url' ),
                'a7v_hero_cta2'     => array( 'متن دکمه دوم (کناری)', 'آغاز مسیر قدرت', 'text' ),
                'a7v_hero_cta2_url' => array( 'لینک دکمه دوم', '#', 'url' ),
                'a7v_hero_sub'      => array( 'زیرنویس دکمه‌ها', 'دسترسی کامل به تمامی محتواها با اشتراک ویژه', 'text' ),
                'a7v_hero_tags'     => array( 'برچسب‌های قدیمی (فقط اگر شعار خالی باشد)', 'دانش | قدرت | ثروت', 'text' ),
        );
        foreach ( $hero_fields as $id => $f ) {
                $wp_customize->add_setting( $id, array(
                        'default'           => $f[1],
                        'sanitize_callback' => 'wp_kses_post',
                ) );
                $wp_customize->add_control( $id, array(
                        'label'   => $f[0],
                        'section' => 'a7v_hero',
                        'type'    => $f[2],
                ) );
        }

        $wp_customize->add_setting( 'a7v_hero_title_color', array( 'default' => '#e01e2b', 'sanitize_callback' => 'sanitize_hex_color' ) );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'a7v_hero_title_color', array(
                'label'   => 'رنگ عنوان اصلی (آکادمی)',
                'section' => 'a7v_hero',
        ) ) );
        $wp_customize->add_setting( 'a7v_hero_accent_color', array( 'default' => '#e01e2b', 'sanitize_callback' => 'sanitize_hex_color' ) );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'a7v_hero_accent_color', array(
                'label'   => 'رنگ عنوان برجسته (مافیا)',
                'section' => 'a7v_hero',
        ) ) );
        $wp_customize->add_setting( 'a7v_hero_title_glow', array(
                'default'           => '40',
                'sanitize_callback' => 'a7v_sanitize_margin_px',
        ) );
        $wp_customize->add_control( 'a7v_hero_title_glow', array(
                'label'       => 'شدت هاله قرمز دور عنوان هیرو (Glow)',
                'description' => 'شعاع درخشش قرمز دور کلمات آکادمی و مافیا (پیش‌فرض: ۴۰ پیکسل)',
                'section'     => 'a7v_hero',
                'type'        => 'number',
                'input_attrs' => array( 'min' => 0, 'max' => 100, 'step' => 5 ),
        ) );
        $wp_customize->add_setting( 'a7v_hero_mobile_offset', array(
                'default'           => '-60',
                'sanitize_callback' => 'a7v_sanitize_offset_px',
        ) );
        $wp_customize->add_control( 'a7v_hero_mobile_offset', array(
                'label'       => 'جابجایی عمودی هیرو روی عکس در موبایل (پیکسل)',
                'description' => 'با مقدار منفی (مثلاً -60 یا -80)، کل متن و آمار در موبایل بالاتر رفته و روی عکس قرار می‌گیرد (پیش‌فرض: -60)',
                'section'     => 'a7v_hero',
                'type'        => 'number',
                'input_attrs' => array( 'min' => -250, 'max' => 100, 'step' => 5 ),
        ) );
        $wp_customize->add_setting( 'a7v_hero_tagline_top', array(
                'default'           => '24',
                'sanitize_callback' => 'a7v_sanitize_margin_px',
        ) );
        $wp_customize->add_control( 'a7v_hero_tagline_top', array(
                'label'       => 'فاصله بالای متن شعار (پیکسل)',
                'description' => 'فاصله بین عنوان آکادمی مافیا و شعار (پیش‌فرض: ۲۴)',
                'section'     => 'a7v_hero',
                'type'        => 'number',
                'input_attrs' => array( 'min' => 0, 'max' => 150, 'step' => 2 ),
        ) );
        $wp_customize->add_setting( 'a7v_hero_tagline_bot', array(
                'default'           => '32',
                'sanitize_callback' => 'a7v_sanitize_margin_px',
        ) );
        $wp_customize->add_control( 'a7v_hero_tagline_bot', array(
                'label'       => 'فاصله پایین متن شعار (پیکسل)',
                'description' => 'فاصله بین شعار و متن توضیحات (پیش‌فرض: ۳۲)',
                'section'     => 'a7v_hero',
                'type'        => 'number',
                'input_attrs' => array( 'min' => 0, 'max' => 150, 'step' => 2 ),
        ) );

        $wp_customize->add_setting( 'a7v_hero_img', array( 'sanitize_callback' => 'esc_url_raw' ) );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'a7v_hero_img', array(
                'label'   => 'تصویر قهرمان',
                'section' => 'a7v_hero',
        ) ) );

        /* ---------- Dark Ambient Music in Header ---------- */
        $wp_customize->add_setting( 'a7v_ambient_enable', array(
                'default'           => true,
                'sanitize_callback' => 'a7v_sanitize_checkbox',
        ) );
        $wp_customize->add_control( 'a7v_ambient_enable', array(
                'label'       => 'نمایش دکمه پخش موزیک دارک در هدر',
                'description' => 'دکمه پخش/توقف موزیک مرموز و سینمایی در کنار حساب کاربری',
                'section'     => 'a7v_hero',
                'type'        => 'checkbox',
        ) );
        $wp_customize->add_setting( 'a7v_ambient_url', array(
                'default'           => '',
                'sanitize_callback' => 'esc_url_raw',
        ) );
        $wp_customize->add_control( 'a7v_ambient_url', array(
                'label'       => 'لینک فایل موزیک اختصاصی (MP3)',
                'description' => 'اختیاری: اگر خالی باشد، موزیک دارک سینمایی داخلی (بدون نیاز به فایل) پخش می‌شود.',
                'section'     => 'a7v_hero',
                'type'        => 'url',
        ) );
        $wp_customize->add_control( 'a7v_ambient_enable_sec', array(
                'settings'    => 'a7v_ambient_enable',
                'label'       => 'نمایش دکمه پخش موزیک در هدر سایت',
                'description' => 'دکمه پخش/توقف موزیک مرموز و سینمایی در کنار حساب کاربری',
                'section'     => 'a7v_live_music_sec',
                'type'        => 'checkbox',
        ) );
        $wp_customize->add_control( new WP_Customize_Upload_Control( $wp_customize, 'a7v_ambient_url_upload', array(
                'settings'    => 'a7v_ambient_url',
                'label'       => 'آپلود فایل صوتی موزیک زنده (MP3)',
                'description' => 'موزیک دلخواه خود را از کامپیوتر یا کتابخانه رسانه برای پخش زنده روی سایت آپلود کنید.',
                'section'     => 'a7v_live_music_sec',
        ) ) );
        /* Also show column selectors inside main hero section for instant access */
        $wp_customize->add_control( 'a7v_hero_stats_cols_pc_in_hero', array(
                'settings'    => 'a7v_hero_stats_cols_pc',
                'label'       => 'تعداد کارت در هر ردیف — کامپیوتر/دسکتاپ',
                'section'     => 'a7v_hero',
                'type'        => 'select',
                'choices'     => array(
                        '4' => '۴ کارت در هر ردیف (پیش‌فرض)',
                        '3' => '۳ کارت در هر ردیف',
                        '2' => '۲ کارت در هر ردیف',
                        '1' => '۱ کارت در هر ردیف',
                ),
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_box_style_in_hero', array(
                'settings'    => 'a7v_hero_stats_box_style',
                'label'       => 'حالت نمایش کارت‌های آمار (کادر و پس‌زمینه)',
                'section'     => 'a7v_hero',
                'type'        => 'select',
                'choices'     => array(
                        'box'   => 'حالت با کادر و پس‌زمینه (باکس شیشه‌ای — پیش‌فرض)',
                        'nobox' => 'حالت آزاد (بدون پس‌زمینه و بدون کادر)',
                ),
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_cols_tablet_in_hero', array(
                'settings'    => 'a7v_hero_stats_cols_tablet',
                'label'       => 'تعداد کارت در هر ردیف — تبلت',
                'section'     => 'a7v_hero',
                'type'        => 'select',
                'choices'     => array(
                        '4' => '۴ کارت در هر ردیف (پیش‌فرض)',
                        '2' => '۲ کارت در هر ردیف (شبکه ۲×۲)',
                        '1' => '۱ کارت در هر ردیف',
                ),
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_cols_mobile_in_hero', array(
                'settings'    => 'a7v_hero_stats_cols_mobile',
                'label'       => 'تعداد کارت در هر ردیف — موبایل/گوشی',
                'section'     => 'a7v_hero',
                'type'        => 'select',
                'choices'     => array(
                        '4' => '۴ کارت در هر ردیف (۱ ردیف افقی — پیش‌فرض)',
                        '2' => '۲ کارت در هر ردیف (شبکه ۲×۲)',
                        '1' => '۱ کارت در هر ردیف',
                ),
        ) );
        $wp_customize->add_setting( 'a7v_hero_stats_enable', array(
                'default'           => true,
                'sanitize_callback' => 'a7v_sanitize_checkbox',
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_enable', array(
                'label'       => 'نمایش ۴ کارت آمار در هیرو (طرح شماره ۲)',
                'section'     => 'a7v_hero_stats_sec',
                'type'        => 'checkbox',
        ) );
        $wp_customize->add_setting( 'a7v_hero_stats_speed', array(
                'default'           => '2200',
                'sanitize_callback' => 'a7v_sanitize_speed_ms',
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_speed', array(
                'label'       => 'سرعت انیمیشن شمارنده (میلی‌ثانیه)',
                'description' => 'مدت زمان انیمیشن شمارش (پیش‌فرض: ۲۲۰۰ میلی‌ثانیه — لوکس و آرام)',
                'section'     => 'a7v_hero_stats_sec',
                'type'        => 'number',
                'input_attrs' => array( 'min' => 500, 'max' => 10000, 'step' => 100 ),
        ) );
        $wp_customize->add_setting( 'a7v_hero_stats_color', array(
                'default'           => '#e01e2b',
                'sanitize_callback' => 'sanitize_hex_color',
        ) );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'a7v_hero_stats_color', array(
                'label'   => 'رنگ قرمز افکت‌ها و آیکون آمار',
                'section' => 'a7v_hero_stats_sec',
        ) ) );
        $wp_customize->add_setting( 'a7v_hero_stats_box_style', array(
                'default'           => 'box',
                'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_box_style', array(
                'label'       => 'حالت نمایش کارت‌های آمار (کادر و پس‌زمینه)',
                'description' => 'نمایش با کادر و باکس شیشه‌ای یا حالت آزاد بدون پس‌زمینه و بدون کادر',
                'section'     => 'a7v_hero_stats_sec',
                'type'        => 'select',
                'choices'     => array(
                        'box'   => 'حالت با کادر و پس‌زمینه (باکس شیشه‌ای — پیش‌فرض)',
                        'nobox' => 'حالت آزاد (بدون پس‌زمینه و بدون کادر)',
                ),
        ) );
        $wp_customize->add_setting( 'a7v_hero_stats_cols_pc', array(
                'default'           => '4',
                'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_cols_pc', array(
                'label'       => 'تعداد کارت در هر ردیف — کامپیوتر/دسکتاپ',
                'section'     => 'a7v_hero_stats_sec',
                'type'        => 'select',
                'choices'     => array(
                        '4' => '۴ کارت در هر ردیف (پیش‌فرض)',
                        '3' => '۳ کارت در هر ردیف',
                        '2' => '۲ کارت در هر ردیف',
                        '1' => '۱ کارت در هر ردیف',
                ),
        ) );
        $wp_customize->add_setting( 'a7v_hero_stats_cols_tablet', array(
                'default'           => '4',
                'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_cols_tablet', array(
                'label'       => 'تعداد کارت در هر ردیف — تبلت',
                'section'     => 'a7v_hero_stats_sec',
                'type'        => 'select',
                'choices'     => array(
                        '4' => '۴ کارت در هر ردیف (پیش‌فرض)',
                        '2' => '۲ کارت در هر ردیف (شبکه ۲×۲)',
                        '1' => '۱ کارت در هر ردیف',
                ),
        ) );
        $wp_customize->add_setting( 'a7v_hero_stats_cols_mobile', array(
                'default'           => '4',
                'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( 'a7v_hero_stats_cols_mobile', array(
                'label'       => 'تعداد کارت در هر ردیف — موبایل/گوشی',
                'section'     => 'a7v_hero_stats_sec',
                'type'        => 'select',
                'choices'     => array(
                        '4' => '۴ کارت در هر ردیف (۱ ردیف افقی — پیش‌فرض)',
                        '2' => '۲ کارت در هر ردیف (شبکه ۲×۲)',
                        '1' => '۱ کارت در هر ردیف',
                ),
        ) );

        $stats_defaults = array(
                1 => array( 'gem',     '90',   '+', 'تعداد محصولات' ),
                2 => array( 'book',    '60',   '+', 'تعداد خلاصه کتاب ها' ),
                3 => array( 'article', '110',  '+', 'تعداد مقالات ویژه' ),
                4 => array( 'users',   '5000', '+', 'تعداد مشتریان' ),
        );
        foreach ( $stats_defaults as $idx => $def ) {
                $wp_customize->add_setting( "a7v_stat{$idx}_icon", array( 'default' => $def[0], 'sanitize_callback' => 'sanitize_text_field' ) );
                $wp_customize->add_control( "a7v_stat{$idx}_icon", array(
                        'label'   => "کارت {$idx} — آیکون",
                        'section' => 'a7v_hero_stats_sec',
                        'type'    => 'select',
                        'choices' => array(
                                'gem'     => 'الماس (Gem)',
                                'book'    => 'کتاب (Book)',
                                'article' => 'قلم / مقاله (Article)',
                                'users'   => 'کاربران / مشتریان (Users)',
                                'course'  => 'دوره آموزشی (Course)',
                                'crown'   => 'تاج VIP (Crown)',
                                'mafia'   => 'مافیا (Mafia)',
                                'income'  => 'درآمد / ثروت (Income)',
                                'badge'   => 'نشان (Badge)',
                                'tool'    => 'ابزار (Tool)',
                        ),
                ) );
                $wp_customize->add_setting( "a7v_stat{$idx}_num", array( 'default' => $def[1], 'sanitize_callback' => 'sanitize_text_field' ) );
                $wp_customize->add_control( "a7v_stat{$idx}_num", array( 'label' => "کارت {$idx} — عدد هدف", 'section' => 'a7v_hero_stats_sec', 'type' => 'text' ) );
                $wp_customize->add_setting( "a7v_stat{$idx}_suffix", array( 'default' => $def[2], 'sanitize_callback' => 'sanitize_text_field' ) );
                $wp_customize->add_control( "a7v_stat{$idx}_suffix", array( 'label' => "کارت {$idx} — پسوند (مثلاً +)", 'section' => 'a7v_hero_stats_sec', 'type' => 'text' ) );
                $wp_customize->add_setting( "a7v_stat{$idx}_title", array( 'default' => $def[3], 'sanitize_callback' => 'sanitize_text_field' ) );
                $wp_customize->add_control( "a7v_stat{$idx}_title", array( 'label' => "کارت {$idx} — عنوان", 'section' => 'a7v_hero_stats_sec', 'type' => 'text' ) );
        }

        $cats_defaults = array(
                1 => array( 'course',  'دوره‌های آموزشی', 'یادگیری مهارت‌های حرفه‌ای و کاربردی', '۲۵ دوره',   get_post_type_archive_link( 'a7v_course' ) ),
                2 => array( 'book',    'خلاصه کتاب‌ها',   'خلاصه و تحلیل کتاب‌های ارزشمند',     '۵۰ خلاصه',  get_post_type_archive_link( 'a7v_book' ) ),
                3 => array( 'mafia',   'مقالات مافیایی',  'دانش، سبک زندگی و رازهای مافیا',      '۴۰ مقاله',  get_post_type_archive_link( 'a7v_mafia' ) ),
                4 => array( 'article', 'مقالات ویژه',    'محتوای اختصاصی و حرفه‌ای',           '۳۰ مقاله',  get_post_type_archive_link( 'a7v_article' ) ),
        );
        foreach ( $cats_defaults as $cidx => $cdef ) {
                $wp_customize->add_setting( "a7v_cat{$cidx}_icon", array( 'default' => $cdef[0], 'sanitize_callback' => 'sanitize_text_field' ) );
                $wp_customize->add_control( "a7v_cat{$cidx}_icon", array(
                        'label'   => "کارت {$cidx} — آیکون",
                        'section' => 'a7v_cats_sec',
                        'type'    => 'select',
                        'choices' => array(
                                'course'  => 'دوره آموزشی (Course)',
                                'book'    => 'کتاب (Book)',
                                'mafia'   => 'مافیا (Mafia)',
                                'article' => 'مقاله / قلم (Article)',
                                'gem'     => 'الماس (Gem)',
                                'users'   => 'کاربران (Users)',
                                'crown'   => 'تاج VIP (Crown)',
                                'tool'    => 'ابزار (Tool)',
                        ),
                ) );
                $wp_customize->add_setting( "a7v_cat{$cidx}_title", array( 'default' => $cdef[1], 'sanitize_callback' => 'sanitize_text_field' ) );
                $wp_customize->add_control( "a7v_cat{$cidx}_title", array( 'label' => "کارت {$cidx} — عنوان اصلی", 'section' => 'a7v_cats_sec', 'type' => 'text' ) );
                $wp_customize->add_setting( "a7v_cat{$cidx}_sub", array( 'default' => $cdef[2], 'sanitize_callback' => 'sanitize_text_field' ) );
                $wp_customize->add_control( "a7v_cat{$cidx}_sub", array( 'label' => "کارت {$cidx} — زیرعنوان", 'section' => 'a7v_cats_sec', 'type' => 'text' ) );
                $wp_customize->add_setting( "a7v_cat{$cidx}_count", array( 'default' => $cdef[3], 'sanitize_callback' => 'sanitize_text_field' ) );
                $wp_customize->add_control( "a7v_cat{$cidx}_count", array( 'label' => "کارت {$cidx} — تعداد محتوا (مثلاً ۲۵ دوره)", 'section' => 'a7v_cats_sec', 'type' => 'text' ) );
                $wp_customize->add_setting( "a7v_cat{$cidx}_url", array( 'default' => $cdef[4], 'sanitize_callback' => 'esc_url_raw' ) );
                $wp_customize->add_control( "a7v_cat{$cidx}_url", array( 'label' => "کارت {$cidx} — لینک دسته‌بندی", 'section' => 'a7v_cats_sec', 'type' => 'url' ) );
        }

        /* ---------- Homepage sections toggle ---------- */
        $wp_customize->add_section( 'a7v_sections', array(
                'title' => 'بخش‌های صفحه اصلی',
                'panel' => 'a7v_panel',
        ) );

        $sections = array(
                'a7v_show_cats'    => 'نوار دسته‌ها',
                'a7v_show_vip'     => 'بنر اشتراک VIP',
                'a7v_show_rows'    => 'ردیف‌های محتوا',
                'a7v_show_benefits'=> 'مزایای عضویت',
                'a7v_show_testi'   => 'نظرات کاربران',
                'a7v_show_faq'     => 'سوالات متداول',
                'a7v_show_notice'  => 'نوار اعلان بالا',
        );
        foreach ( $sections as $id => $label ) {
                $wp_customize->add_setting( $id, array(
                        'default'           => true,
                        'sanitize_callback' => 'a7v_sanitize_checkbox',
                ) );
                $wp_customize->add_control( $id, array(
                        'label'   => 'نمایش: ' . $label,
                        'section' => 'a7v_sections',
                        'type'    => 'checkbox',
                ) );
        }

        /* ---------- Marquee ---------- */
        $wp_customize->add_section( 'a7v_marquee', array(
                'title' => 'نوار متحرک (Marquee)',
                'panel' => 'a7v_panel',
        ) );
        $wp_customize->add_setting( 'a7v_marquee_loop', array(
                'default'           => true,
                'sanitize_callback' => 'a7v_sanitize_checkbox',
        ) );
        $wp_customize->add_control( 'a7v_marquee_loop', array(
                'label'   => 'حرکت بینهایت (Loop)',
                'description' => 'آیتم‌ها به صورت بی‌نهایت حرکت کنند',
                'section' => 'a7v_marquee',
                'type'    => 'checkbox',
        ) );
        $wp_customize->add_setting( 'a7v_marquee_speed', array(
                'default'           => '50',
                'sanitize_callback' => 'a7v_sanitize_speed',
        ) );
        $wp_customize->add_control( 'a7v_marquee_speed', array(
                'label'       => 'سرعت حرکت (ثانیه)',
                'description' => 'هرچه عدد بزرگ‌تر باشد، حرکت کندتر است. (پیش‌فرض: ۵۰ — کند و لوکس)',
                'section'     => 'a7v_marquee',
                'type'        => 'number',
                'input_attrs' => array( 'min' => 5, 'max' => 200, 'step' => 1 ),
        ) );
        $wp_customize->add_setting( 'a7v_marquee_dir', array(
                'default'           => 'right',
                'sanitize_callback' => 'a7v_sanitize_dir',
        ) );
        $wp_customize->add_control( 'a7v_marquee_dir', array(
                'label'       => 'جهت حرکت نوار متحرک',
                'description' => 'جهت حرکت آیتم‌ها روی صفحه',
                'section'     => 'a7v_marquee',
                'type'        => 'select',
                'choices'     => array(
                        'right' => 'به سمت راست (حرکت به راست — پیش‌فرض)',
                        'left'  => 'به سمت چپ (حرکت به چپ)',
                ),
        ) );

        /* ---------- VIP banner ---------- */
        $wp_customize->add_section( 'a7v_vip', array(
                'title' => 'اشتراک ویژه',
                'panel' => 'a7v_panel',
        ) );
        $wp_customize->add_setting( 'a7v_vip_link', array( 'default' => '#', 'sanitize_callback' => 'esc_url_raw' ) );
        $wp_customize->add_control( 'a7v_vip_link', array( 'label' => 'لینک صفحه پلن‌ها', 'section' => 'a7v_vip', 'type' => 'url' ) );

        /* ---------- Dossier (product info box) ---------- */
        $wp_customize->add_section( 'a7v_dossier_display', array(
                'title' => 'پرونده اطلاعات (نمایش)',
                'panel' => 'a7v_panel',
        ) );
        $wp_customize->add_setting( 'a7v_dossier_mobile_cols', array(
                'default'           => 3,
                'sanitize_callback' => 'a7v_sanitize_dossier_cols',
        ) );
        $wp_customize->add_control( 'a7v_dossier_mobile_cols', array(
                'label'       => 'تعداد آیکون در هر ردیف (موبایل)',
                'description' => 'در گوشی، آیکون‌های باکس «پرونده اطلاعات» در هر ردیف چند تا باشند؟ (۱ تا ۴ — پیش‌فرض ۳)',
                'section'     => 'a7v_dossier_display',
                'type'        => 'select',
                'choices'     => array(
                        1 => '۱ آیکون در هر ردیف',
                        2 => '۲ آیکون در هر ردیف',
                        3 => '۳ آیکون در هر ردیف (پیش‌فرض)',
                        4 => '۴ آیکون در هر ردیف',
                ),
        ) );

        /* ---------- Footer ---------- */
        $wp_customize->add_section( 'a7v_footer', array(
                'title' => 'فوتر',
                'panel' => 'a7v_panel',
        ) );
        $footer_fields = array(
                'a7v_footer_about'   => array( 'متن درباره', 'آکادمی مافیا، بزرگ‌ترین مرجع آموزش و رشد فردی در زمینه‌های کسب‌وکار، روانشناسی، موفقیت و قدرت.' ),
                'a7v_copyright'      => array( 'متن کپی‌رایت', '© 2025 A7V Academy. All Rights Reserved.' ),
                'a7v_social_tg'      => array( 'لینک تلگرام', '#' ),
                'a7v_social_ig'      => array( 'لینک اینستاگرام', '#' ),
                'a7v_social_yt'      => array( 'لینک یوتیوب', '#' ),
        );
        foreach ( $footer_fields as $id => $f ) {
                $wp_customize->add_setting( $id, array( 'default' => $f[1], 'sanitize_callback' => 'wp_kses_post' ) );
                $wp_customize->add_control( $id, array( 'label' => $f[0], 'section' => 'a7v_footer', 'type' => 'text' ) );
        }
}
add_action( 'customize_register', 'a7v_customize_register' );

function a7v_sanitize_checkbox( $v ) {
        return ( isset( $v ) && true == $v ) ? true : false;
}

/** Clamp the dossier mobile columns setting to 1-4. */
function a7v_sanitize_dossier_cols( $v ) {
        $v = (int) $v;
        if ( $v < 1 ) { $v = 1; }
        if ( $v > 4 ) { $v = 4; }
        return $v;
}

/** Clamp marquee speed to 5–200 seconds. */
function a7v_sanitize_speed( $v ) {
        $v = (float) $v;
        if ( $v < 5 )  { $v = 5; }
        if ( $v > 200 ) { $v = 200; }
        return $v;
}

/** Clamp counter animation speed to 500-10000ms. */
function a7v_sanitize_speed_ms( $v ) {
        $v = (int) $v;
        if ( $v < 500 ) { $v = 500; }
        if ( $v > 10000 ) { $v = 10000; }
        return $v;
}

/** Sanitize marquee direction setting. */
function a7v_sanitize_dir( $v ) {
        return ( 'left' === $v ) ? 'left' : 'right';
}

/** Clamp margin spacing setting to 0-150 pixels. */
function a7v_sanitize_margin_px( $v ) {
        $v = (int) $v;
        if ( $v < 0 )   { $v = 0; }
        if ( $v > 150 ) { $v = 150; }
        return $v;
}

/** Clamp vertical offset to -250..100 px. */
function a7v_sanitize_offset_px( $v ) {
        $v = (int) $v;
        if ( $v < -250 ) { $v = -250; }
        if ( $v > 100 )  { $v = 100; }
        return $v;
}

/**
 * Inline CSS from customizer color settings.
 */
function a7v_dynamic_css() {
        $brand = get_theme_mod( 'a7v_brand', '#e01e2b' );
        $glow  = get_theme_mod( 'a7v_glow', '#ff3b3b' );
        $gold  = get_theme_mod( 'a7v_gold', '#c9a24b' );
        $bg    = get_theme_mod( 'a7v_bg', '#070708' );
        $dcols = (int) get_theme_mod( 'a7v_dossier_mobile_cols', 3 );
        if ( $dcols < 1 ) { $dcols = 1; }
        if ( $dcols > 4 ) { $dcols = 4; }
        return ":root{--blood:{$brand};--blood-glow:{$glow};--gold:{$gold};--bg-abyss:{$bg};--dossier-mcols:{$dcols};}";
}
